#ifndef _COUNTING_SORT_H_
#define _COUNTING_SORT_H_

#define RANGE 255 // The input array will have integer elements ranging from 0 to RANGE
#define NUM_ELEMENTS 100000000 // Number of elements in the input array
// #define DEBUG_FLAG 

#endif
